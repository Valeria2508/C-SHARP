﻿using Escuela.Models;
AdministradorApp.EstudiantesEj();
AdministradorApp.ProfesoresEj();
AdministradorApp.Menu();